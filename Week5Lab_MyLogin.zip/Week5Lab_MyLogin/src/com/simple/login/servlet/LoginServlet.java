package com.simple.login.servlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.simple.login.service.AccountService;
import com.simple.login.service.User;

/**
 * Servlet implementation class LoginServlet
 */
@WebServlet("/login")
public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		String logout = request.getParameter("logout");
		// Check if "logout" parameter is present
		if (logout != null) {
			HttpSession session = request.getSession();
			// Invalidate the session
			session.invalidate();
			// Set a message indicating that the user has logged out
			request.setAttribute("error", "You have been logged out successfully.");
			// Forward the request to the login page
			request.getRequestDispatcher("/login.jsp").forward(request, response);
		} else {
			// Forward the request to the login page
			request.getRequestDispatcher("/login.jsp").forward(request, response);
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		String username = request.getParameter("username");
		String password = request.getParameter("password");

		if (username == null || username.trim().isEmpty() || password == null || password.trim().isEmpty()) {
			request.setAttribute("error", "Username and password cannot be empty.");
			request.getRequestDispatcher("/login.jsp").forward(request, response);
			return;
		}
		AccountService accountService = new AccountService();
		User user = accountService.login(username, password);
		if (user != null) {
			// Store the username in the session
			HttpSession session = request.getSession();
			session.setAttribute("username", user.getUsername());
			// Redirect the user to the home page
			response.sendRedirect("home.jsp");
		} else {
			// Set an error message
			request.setAttribute("error", "Invalid username or password.");
			// Forward the request to the login page
			request.getRequestDispatcher("/login.jsp").forward(request, response);
		}
	}

}
