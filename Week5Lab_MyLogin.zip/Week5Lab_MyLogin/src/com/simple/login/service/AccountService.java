package com.simple.login.service;

public class AccountService {

	public User login(String username, String password) {

		// Validate the user name and password
		if (username.equals("abe") && password.equals("password")) {
			User user = new User();
			user.setUsername(username);
			return user;
		} else if (username.equals("barb") && password.equals("password")) {
			User user = new User();
			user.setUsername(username);
			return user;
		}
		return null;
	}

}
